# Aplicación de citas profesionales


## Requirements
pip install -r requirements.txt

Cuidado con la librería de click. Necesita click~=7.0 y por defecto instala la 8.1

